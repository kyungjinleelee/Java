package exam09;

public class ExceptionTest {

	public static void main(String[] args) {
		// 정상 종료
		System.out.println("1");
		System.out.println("2");
		
		System.out.println("end. 정상종료");

	}

}
